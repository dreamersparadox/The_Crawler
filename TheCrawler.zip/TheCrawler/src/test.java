import java.util.Scanner;

/**
 * Example program to
 *  list links from a URL.
 */
public class test 
{
	public static void main(String[] args) 
	{
	    Scanner s = new Scanner(System.in);
	    System.out.println("Enter a string:");
	    String ss = s.nextLine();
	    System.out.println(ss);
	}
}